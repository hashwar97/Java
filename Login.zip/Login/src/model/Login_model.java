package model;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import bean.Login_Bean;
import dbconnection.DB_Connection;;
public class Login_model {

	public boolean validate(Login_Bean obj_Login_Bean) {
		boolean flag=false;
		DB_Connection obj_DB_Connection=new DB_Connection();
		
		Connection connection=obj_DB_Connection.getConnection();
		PreparedStatement ps=null;
		ResultSet rs=null;
		try {
			String query="select * from login where user_name=? and password=?";
			ps=connection.prepareStatement(query);
			
			ps.setString(1,obj_Login_Bean.getUser_name());
			ps.setString(2,obj_Login_Bean.getPassword());
			
			rs=ps.executeQuery();
			if(rs.next())
			{
				flag=true;
			}
		} catch (Exception e) {
			// TODO: handle exception
		} 
		finally {
			if(connection!=null) {
				try {
					connection.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			// TODO: handle finally clause
		}
		
		
		return flag;
	}
}
